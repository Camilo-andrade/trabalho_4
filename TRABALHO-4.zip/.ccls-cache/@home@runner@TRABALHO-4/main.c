#include <stdio.h>
#include <stdlib.h>
int aux;

typedef struct No {
  char letra;
  struct node *prev;
  struct node *next;
} No;

typedef struct Lista {
  No *inicio;
  No *final;
} Lista;

void iniciar(Lista *lista) {
  lista->inicio = NULL;
  lista->final = NULL;
}

void adicionar(char l, Lista *lista) {
  No *item = (No *)malloc(sizeof(No));

  if (lista->inicio == NULL) {
    lista->inicio = item;
  } else {
    lista->final->next = item;
  }

  item->letra = l;
  item->prev = lista->final;
  lista->final = item;
  aux++;
}

void imprimirInicio(Lista *lista) {
  No *item = lista->inicio;
  while (item != NULL) {
    printf("%c", toupper(item->letra));
    item = item->next;
  }
  printf("\n");
}

void imprimirFinal(Lista *lista) {
  No *item = lista->final;
  while (item != NULL) {
    printf("%c", toupper(item->letra));
    item = item->prev;
  }
  printf("\n");
}

void imprimirApartir(Lista *lista) {
  No *item = lista->inicio;
  for (int i = 0; i < (aux / 2); i++) {
    item = item->next;
  }

  while (item != NULL) {
    printf("%c", toupper(item->letra));
    item = item->next;
  }

  printf("\n");
}

int main() {
  Lista *lista = (Lista *)malloc(sizeof(Lista));
  iniciar(lista);
  adicionar('c', lista);
  adicionar('a', lista);
  adicionar('m', lista);
  adicionar('i', lista);
  adicionar('l', lista);
  adicionar('o', lista);
  imprimirInicio(lista);
  imprimirFinal(lista);
  imprimirApartir(lista);
}